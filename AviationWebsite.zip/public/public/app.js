
const express = require('express')
const request = require('request')
const bodyParser = require('body-parser');
const path = require('path')

const app = express();

app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')))

app.get('/', (req, res) => {
  res.send('WORKING');
});

app.post('/sub', (req, res) => {
    const { email, js } = req.body;
    console.log(req.body);

    const mcData = {
        members: [
            {
                email_address: email,
                status: 'pending'
                
            }
        ]

}
    const mcDataPost = JSON.stringify(mcData);
    
    const options = {
        url: 'https://us8.api.mailchimp.com/3.0/lists/af2155daa6',
        method: 'POST',
        headers: {
            Authorization: 'auth 5b9f81ccbe11f23723a7497dd5d1eca7-us8  '
        },
        body: mcDataPost
    }
    if (email) {
        request(options, (err, response, body) => {
            if (err) {
                res.json({ error: err })
            } else
                if (js) {
                    res.sendStatus(200);
                } else {
                    res.redirect('/success.html')
                }

        })
    } else {
        res.status(404).send({ message: 'failed' })
    }

})

const PORT = process.env.port || 5000;

app.listen(PORT, console.log('server started'));

